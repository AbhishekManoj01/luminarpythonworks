# colors=["red","green","blue"]
# # print(colors)
# # popped=colors.pop(1)
# # print(colors)
# # print(popped)
# # colors.insert(0,"purple")
# # print(colors)
# # ind=colors.index("green")
# # print(ind)
# # print(colors[ind])
# colors1=colors.copy() #creating exact copy of the list colors
# colors1.pop() # removing last object from new list
# print(colors1)

#class list:
    # def sort(self,reverse=False) asc

# arr=[2,1,3,5,4]
# arr.sort(reverse=True)
# print(arr)
fruits=["apple","orange","mango"]
fruits.reverse() #reverse a list
print(fruits)
products=["onion","potato","brinjal"]
products.extend(fruits) # add list elemets to another list
print(products)
