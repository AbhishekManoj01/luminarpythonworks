lis=[2,3,4,5]
tot=sum(lis)
for i in range(len(lis)):
    print(tot-lis[i],end=",")
# print()
# listt=[3,6,7]
# tot=sum(listt)
# for i in range(len(listt)):
#     print(tot-listt[i],end=",")
