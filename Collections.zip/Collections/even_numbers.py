arr=[1,2,4,5,6,7,8,9,10,11]
for i in range(len(arr)):
    if arr[i]%2==0:
        print(arr[i])