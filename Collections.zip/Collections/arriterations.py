arr=[10,20,30,40]
for i in range(len(arr)):
    print(arr[i],end=" ")