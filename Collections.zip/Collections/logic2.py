lis=[2,3,4,5]
tot=0
for i in range(len(lis)):
    tot+=lis[i]
for j in range(len(lis)):
    print(tot-lis[j],end=",")
    
print()

listt=[3,6,7]
tot=0
for i in range(len(listt)):
    tot+=listt[i]
for j in range(len(listt)):
    print(tot-listt[j],end=",")