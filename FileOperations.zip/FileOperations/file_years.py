f=open("C:\\Users\\ajay\\Desktop\\pythonworks\\datasets\\years.txt","w")
for y in range(1790,2025):
    f.write(str(y)+"\n")
f.close()