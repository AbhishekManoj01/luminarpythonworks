f=open("datasets\students.txt","r")
for line in f:
    print(line)