f=open("C:\\Users\\ajay\\Desktop\\pythonworks\\datasets\\names.txt","w")
languages=["Python","java","Cpp","javascript"]
for l in languages:
    f.write(l+"\n")
f.close()