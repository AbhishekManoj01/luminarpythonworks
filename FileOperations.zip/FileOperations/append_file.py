f=open("C:\\Users\\ajay\\Desktop\\pythonworks\\datasets\\framework.txt","a")
frame_work=["wordpress","springboot","odoo","fastapi"]
for fw in frame_work:
    f.write(fw+"\n")
f.close()