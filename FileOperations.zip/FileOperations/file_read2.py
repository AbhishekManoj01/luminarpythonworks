f=open("C:\\Users\\ajay\\Desktop\\pythonworks\\datasets\course_details.txt","r")

for line in f:
    print(line,end="")
